
<center>



<h3   style=color:#FF0000>



<form    action="post55555555.php" method="post">
 

<table border="2">
<tr>
<td>

<h3   style=color:#FF0000>



请选择前区号码最少选5个##：<br><hr>

<table border="2">
<tr>


<td>

<td>

<td>

<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="1['1']" value="1">1<br />
<td/>
<td>



<h3   style=color:#FF0000>


<input type="checkbox" name="2['2']"
value="2">2<br>

<td/>

<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="3['3']" value="3">3<br />

<td/>
<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="4['4']" value="4">4<br />
<td/>

<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="5['5']" value="5">5<br />





<td/>


<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="6['6']" value="6">6<br />

<td/>

<td>



<h3   style=color:#FF0000>

<input type="checkbox" name="7['7']" value="7">7<br />
<td/>
<td>



<h3   style=color:#FF0000>


<input type="checkbox" name="8['8']" value="8">8<br />

<td/>

<td>

<tr/>

<tr>


<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>

<td>




<tr/>


<tr>



<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>



<td>

<tb>


<td>



<h3   style=color:#FF0000>

<input type="checkbox" name="9['9']" value="9">9<br />

<td/>
<td>



<h3   style=color:#FF0000>

<input type="checkbox" name="10['10']" value="10">10<br />

<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="11['11']" value="11">11<br />

<td/>


<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="12['12']" value="12">12<br />


<td/>

<td>




<h3   style=color:#FF0000>


<input type="checkbox" name="13['13']" value="13">13<br />


<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="14['14']" value="14">14<br />

<td/>

<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="15['15']" value="15">15<br />


<td/>

<td>



<h3   style=color:#FF0000>

<input type="checkbox" name="16['16']" value="16">16<br />


<td/>


<td>

<tr/>


<tr>


<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>


<td>

<h3   style=color:#FF0000>

<input type="checkbox" name="17['17']" value="17">17<br />

<td/>


<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="18['18']" value="18">18<br />


<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="19['19']" value="19">19<br />

<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="20['20']" value="20">20<br />


<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="21['21']" value="21">21<br />


<td/>


<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="22['22']" value="22">22<br />

<td/>


<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="23['23']" value="23">23<br />


<td/>

<td>

<h3   style=color:#FF0000>

<input type="checkbox" name="24['24']" value="24">24<br />

<td/>

<tr/>

<tr>

<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>


<td>

<h3   style=color:#FF0000>

<input type="checkbox" name="25['25']" value="25">25<br />


<td/>
<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="26['26']" value="26">26<br />


<td/>
<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="27['27']" value="27">27<br />


<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="28['28']" value="28">28<br />

<td/>

<td>

<h3   style=color:#FF0000>

<input type="checkbox" name="29['29']" value="29">29<br />

<td/>

<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="30['30']" value="30">30<br />

<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="31['31']" value="31">31<br />

<td/>

<tr/>

<tr>


<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="32['32']" value="32">32<br />

<td/>

<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="33['33']" value="33">33<br />

<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="34['34']" value="34">34<br />


<td/>
<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="35['35']" value="35">35<br />


<td/>
<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>

<tr/>



<table/>

<br>

<hr>



<input     style="font-size:40px"    type="submit"   value="开始选号" >




</form>

<div    style=color:#FF0000>


<h3>两行三列前区：{可合2为1}</h3>
<table border="1">
<tr>
  <td>


<?php
echo "<pre>";
echo "<center>";
echo "<h2  style=color:#FF0000  >大乐透POST勾选随机版前区</>";

echo "<h2  style=color:#FF0000 >您勾选的号码是</><td>";




print_r ($_POST);   //打印出勾选号码


echo "<h2 style=color:#FF0000 >您勾选后随机的号码是</><br/>";


print_r(array_rand($_POST,5));   //在勾选号码中随机

echo "<br/>";

print_r(array_rand($_POST,5));   //在勾选号码中随机


?>
<td/>

</tr>

</table>










































